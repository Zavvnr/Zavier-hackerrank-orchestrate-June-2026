"""Allowed values, output schema constants, and row validation for the claim system."""

CLAIM_STATUS = frozenset({"supported", "contradicted", "not_enough_information"})

ISSUE_TYPES = frozenset({
    "dent", "scratch", "crack", "glass_shatter", "broken_part",
    "missing_part", "torn_packaging", "crushed_packaging", "water_damage",
    "stain", "none", "unknown",
})

CAR_PARTS = frozenset({
    "front_bumper", "rear_bumper", "door", "hood", "windshield",
    "side_mirror", "headlight", "taillight", "fender", "quarter_panel",
    "body", "unknown",
})

LAPTOP_PARTS = frozenset({
    "screen", "keyboard", "trackpad", "hinge", "lid", "corner",
    "port", "base", "body", "unknown",
})

PACKAGE_PARTS = frozenset({
    "box", "package_corner", "package_side", "seal", "label",
    "contents", "item", "unknown",
})

OBJECT_PARTS = {
    "car": CAR_PARTS,
    "laptop": LAPTOP_PARTS,
    "package": PACKAGE_PARTS,
}

RISK_FLAGS = frozenset({
    "none", "blurry_image", "cropped_or_obstructed", "low_light_or_glare",
    "wrong_angle", "wrong_object", "wrong_object_part", "damage_not_visible",
    "claim_mismatch", "possible_manipulation", "non_original_image",
    "text_instruction_present", "user_history_risk", "manual_review_required",
})

SEVERITY = frozenset({"none", "low", "medium", "high", "unknown"})

OUTPUT_COLUMNS = [
    "user_id", "image_paths", "user_claim", "claim_object",
    "evidence_standard_met", "evidence_standard_met_reason",
    "risk_flags", "issue_type", "object_part", "claim_status",
    "claim_status_justification", "supporting_image_ids", "valid_image", "severity",
]

SAFE_DEFAULTS = {
    "evidence_standard_met": "false",
    "evidence_standard_met_reason": "Unable to evaluate.",
    "risk_flags": "none",
    "issue_type": "unknown",
    "object_part": "unknown",
    "claim_status": "not_enough_information",
    "claim_status_justification": "Unable to process images.",
    "supporting_image_ids": "none",
    "valid_image": "false",
    "severity": "unknown",
}


def coerce_row(row: dict) -> dict:
    """Validate and coerce a prediction row to use only allowed values."""
    claim_object = row.get("claim_object", "car")
    valid_parts = OBJECT_PARTS.get(claim_object, CAR_PARTS)

    if row.get("claim_status") not in CLAIM_STATUS:
        row["claim_status"] = "not_enough_information"
    if row.get("issue_type") not in ISSUE_TYPES:
        row["issue_type"] = "unknown"
    if row.get("object_part") not in valid_parts:
        row["object_part"] = "unknown"
    if row.get("severity") not in SEVERITY:
        row["severity"] = "unknown"
    if row.get("evidence_standard_met") not in {"true", "false"}:
        row["evidence_standard_met"] = "false"
    if row.get("valid_image") not in {"true", "false"}:
        row["valid_image"] = "false"

    # Validate risk flags — keep only known tokens.
    raw_flags = row.get("risk_flags", "none")
    tokens = [t.strip() for t in raw_flags.split(";") if t.strip()]
    valid_tokens = [t for t in tokens if t in RISK_FLAGS]
    row["risk_flags"] = ";".join(valid_tokens) if valid_tokens else "none"

    # Validate supporting_image_ids — must be img_\d+ tokens or "none".
    raw_ids = row.get("supporting_image_ids", "none")
    if raw_ids.strip().lower() == "none":
        row["supporting_image_ids"] = "none"
    else:
        id_tokens = [t.strip() for t in raw_ids.split(";") if t.strip()]
        row["supporting_image_ids"] = ";".join(id_tokens) if id_tokens else "none"

    return row
