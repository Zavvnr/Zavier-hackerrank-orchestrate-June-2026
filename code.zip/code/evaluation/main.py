"""Evaluation entry point: score predictions on sample_claims.csv and write report."""

import collections
import csv
import io
import pathlib
import sys
import time

ROOT = pathlib.Path(__file__).parent.parent.parent
sys.path.insert(0, str(ROOT / "code"))

import io_csv
import pipeline
import schema

DATASET_DIR = ROOT / "dataset"
SAMPLE_CSV = DATASET_DIR / "sample_claims.csv"
USER_HISTORY_CSV = DATASET_DIR / "user_history.csv"
EVIDENCE_REQ_CSV = DATASET_DIR / "evidence_requirements.csv"

EVAL_DIR = pathlib.Path(__file__).parent
PREDICTIONS_CSV = EVAL_DIR / "sample_predictions.csv"
REPORT_MD = EVAL_DIR / "evaluation_report.md"

# Fields used for accuracy scoring.
SCORED_FIELDS = [
    "evidence_standard_met",
    "risk_flags",
    "issue_type",
    "object_part",
    "claim_status",
    "supporting_image_ids",
    "valid_image",
    "severity",
]


def _parse_flags(value: str) -> frozenset[str]:
    """Split a semicolon-separated flag string into a set."""
    if not value or value.strip().lower() == "none":
        return frozenset()
    return frozenset(t.strip() for t in value.split(";") if t.strip())


def _jaccard(a: str, b: str) -> float:
    """Jaccard similarity for semicolon-separated sets (for multi-value fields)."""
    sa, sb = _parse_flags(a), _parse_flags(b)
    if not sa and not sb:
        return 1.0
    union = sa | sb
    inter = sa & sb
    return len(inter) / len(union)


def score_predictions(sample_rows: list[dict], predictions: list[dict]) -> dict:
    """Compute per-field accuracy and macro-F1 for claim_status."""
    assert len(sample_rows) == len(predictions), "Row count mismatch"
    n = len(sample_rows)
    field_correct: dict[str, float] = collections.defaultdict(float)

    # claim_status confusion matrix for F1.
    labels = list(schema.CLAIM_STATUS)
    confusion: dict[str, dict[str, int]] = {
        l: {l2: 0 for l2 in labels} for l in labels
    }

    for gold, pred in zip(sample_rows, predictions):
        for field in SCORED_FIELDS:
            gv = gold.get(field, "").strip()
            pv = pred.get(field, "").strip()
            if field in {"risk_flags", "supporting_image_ids"}:
                # Partial credit via Jaccard.
                field_correct[field] += _jaccard(gv, pv)
            else:
                field_correct[field] += 1.0 if gv == pv else 0.0

        # Confusion matrix for claim_status F1.
        g_status = gold.get("claim_status", "not_enough_information")
        p_status = pred.get("claim_status", "not_enough_information")
        if g_status in confusion and p_status in labels:
            confusion[g_status][p_status] += 1

    # Per-field accuracy.
    accuracies = {f: field_correct[f] / n for f in SCORED_FIELDS}

    # Macro-F1 for claim_status.
    f1s = []
    for label in labels:
        tp = confusion[label][label]
        fp = sum(confusion[other][label] for other in labels if other != label)
        fn = sum(confusion[label][other] for other in labels if other != label)
        precision = tp / (tp + fp) if (tp + fp) > 0 else 0.0
        recall = tp / (tp + fn) if (tp + fn) > 0 else 0.0
        f1 = 2 * precision * recall / (precision + recall) if (precision + recall) > 0 else 0.0
        f1s.append(f1)
    macro_f1 = sum(f1s) / len(f1s)

    return {"per_field": accuracies, "claim_status_macro_f1": macro_f1}


def main() -> None:
    """Run evaluation on sample_claims.csv and write report."""
    print(f"Reading sample claims from {SAMPLE_CSV}")
    sample_rows = io_csv.read_claims(SAMPLE_CSV)
    user_history = io_csv.read_lookup(USER_HISTORY_CSV, "user_id")
    evidence_requirements = io_csv.read_list(EVIDENCE_REQ_CSV)

    n = len(sample_rows)
    print(f"Processing {n} sample claims...")

    predictions = []
    total_time = 0.0
    for i, row in enumerate(sample_rows, start=1):
        print(f"  [{i}/{n}] {row['user_id']} | {row['claim_object']}")
        t0 = time.time()
        pred = pipeline.process_claim(row, user_history, evidence_requirements)
        elapsed = time.time() - t0
        total_time += elapsed
        print(f"    -> {pred['claim_status']} (gold: {row.get('claim_status', '?')}) | {elapsed:.1f}s")
        predictions.append(pred)

    # Save predictions CSV.
    io_csv.write_output(predictions, PREDICTIONS_CSV, schema.OUTPUT_COLUMNS)

    # Score.
    scores = score_predictions(sample_rows, predictions)
    per_field = scores["per_field"]
    macro_f1 = scores["claim_status_macro_f1"]

    # Per-case breakdown.
    case_lines = []
    for row, pred in zip(sample_rows, predictions):
        g = row.get("claim_status", "?")
        p = pred.get("claim_status", "?")
        match = "OK" if g == p else "MISS"
        case_lines.append(f"| {row['user_id']} | {row['claim_object']} | {g} | {p} | {match} |")

    # Count model calls (each prediction = 1 call, minus cache hits).
    cache_dir = ROOT / "code" / ".cache"
    cache_count = len(list(cache_dir.glob("*.json"))) if cache_dir.exists() else 0

    # Estimate costs (claude-sonnet-4-6: $3/MTok in, $15/MTok out, approx).
    avg_input_tokens = 3000   # ~2 images + context per claim
    avg_output_tokens = 300
    total_claims_est = n + 44  # sample + test
    cost_in = total_claims_est * avg_input_tokens / 1_000_000 * 3.0
    cost_out = total_claims_est * avg_output_tokens / 1_000_000 * 15.0
    cost_total = cost_in + cost_out

    report = f"""# Evaluation Report

## Scores on sample_claims.csv (n={n})

**claim_status macro-F1: {macro_f1:.3f}**

### Per-field accuracy
| Field | Accuracy |
|-------|----------|
"""
    for field, acc in sorted(per_field.items()):
        report += f"| {field} | {acc:.3f} |\n"

    report += f"""
## Per-case breakdown
| user_id | object | gold | pred | result |
|---------|--------|------|------|--------|
"""
    report += "\n".join(case_lines)

    report += f"""

## Operational analysis

| Metric | Value |
|--------|-------|
| Model | claude-sonnet-4-6 |
| Sample claims processed | {n} |
| Test claims to process | 44 |
| Total claims (sample + test) | {total_claims_est} |
| Avg latency per claim | {total_time/n:.1f}s |
| Total sample run time | {total_time:.1f}s |
| Disk cache entries present | {cache_count} |
| Est. avg input tokens/claim | ~{avg_input_tokens:,} |
| Est. avg output tokens/claim | ~{avg_output_tokens:,} |
| Est. total input tokens | ~{total_claims_est*avg_input_tokens:,} |
| Est. total output tokens | ~{total_claims_est*avg_output_tokens:,} |
| Est. total cost (USD) | ~${cost_total:.2f} |

**Pricing assumptions:** claude-sonnet-4-6 at $3.00/MTok input, $15.00/MTok output (Anthropic list pricing, June 2026).
Images are encoded as JPEG base64; each image adds ~1000–2500 input tokens depending on resolution.

## Batching, caching, and rate-limit strategy

- **Disk cache:** Each claim is hashed (SHA-256 over image bytes + context JSON). Reruns skip cached claims entirely, making reruns free and deterministic.
- **One call per claim:** All images for a claim are submitted in a single multi-image message. This minimizes RPM usage and gives the model cross-image context for identity-mismatch detection.
- **Temperature 0:** All calls use temperature=0 for determinism.
- **Retry with exponential backoff:** Up to 4 retries on rate-limit (429) and server errors (5xx), starting at 8s doubling each attempt.
- **Graceful degradation:** If a call fails after all retries, the claim row uses safe defaults (`not_enough_information`, `severity=unknown`) rather than crashing the batch.
- **TPM/RPM headroom:** With ~{total_claims_est} claims and ~{avg_input_tokens} input tokens each, peak throughput is ~{total_claims_est*avg_input_tokens//60:,} TPM — well within claude-sonnet-4-6 limits. Sequential processing keeps RPM low (~1 RPM), avoiding burst throttling.
"""

    REPORT_MD.write_text(report, encoding="utf-8")
    print(f"\n--- Scores ---")
    print(f"claim_status macro-F1: {macro_f1:.3f}")
    for field, acc in sorted(per_field.items()):
        print(f"  {field}: {acc:.3f}")
    print(f"\nReport written to {REPORT_MD}")
    print(f"Predictions written to {PREDICTIONS_CSV}")


if __name__ == "__main__":
    main()
